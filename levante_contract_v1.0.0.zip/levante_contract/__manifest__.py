# -*- coding: utf-8 -*-
{
    "name": "Levante Contracts",
    "summary": "Supplier contracts (gallery / artist / curator) with auto-generated "
               "agreement document and portal access & approval.",
    "version": "19.0.1.0.0",
    "category": "Levante",
    "author": "Levante ERP Project Team",
    "website": "https://levante.art",
    "license": "LGPL-3",
    "depends": ["base", "mail", "portal"],
    "data": [
        "security/security.xml",
        "security/ir.model.access.csv",
        "views/contract_views.xml",
        "report/contract_report.xml",
        "views/portal_templates.xml",
    ],
    "application": True,
    "installable": True,
}
