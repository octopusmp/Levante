# -*- coding: utf-8 -*-
from odoo import http, _
from odoo.exceptions import AccessError, MissingError, UserError
from odoo.http import request
from odoo.addons.portal.controllers.portal import CustomerPortal


class LevanteContractPortal(CustomerPortal):

    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        if "contract_count" in counters:
            values["contract_count"] = request.env["levante.contract"].search_count([
                ("state", "in", ("sent", "approved")),
            ])
        return values

    def _get_contract(self, contract_id):
        contract = request.env["levante.contract"].browse(contract_id).exists()
        if not contract:
            raise MissingError(_("This contract does not exist."))
        # record rules already restrict portal users to their own contracts;
        # this read triggers the access check
        contract.check_access("read")
        return contract

    @http.route(["/my/contracts"], type="http", auth="user", website=True)
    def portal_my_contracts(self, **kw):
        contracts = request.env["levante.contract"].search([
            ("state", "in", ("sent", "approved")),
        ])
        return request.render("levante_contract.portal_my_contracts", {
            "contracts": contracts,
            "page_name": "levante_contracts",
        })

    @http.route(["/my/contracts/<int:contract_id>"], type="http",
                auth="user", website=True)
    def portal_contract_detail(self, contract_id, **kw):
        try:
            contract = self._get_contract(contract_id)
        except (AccessError, MissingError):
            return request.redirect("/my")
        return request.render("levante_contract.portal_contract_page", {
            "contract": contract,
            "page_name": "levante_contracts",
        })

    @http.route(["/my/contracts/<int:contract_id>/approve"], type="http",
                auth="user", website=True, methods=["POST"], csrf=True)
    def portal_contract_approve(self, contract_id, **post):
        try:
            contract = self._get_contract(contract_id)
        except (AccessError, MissingError):
            return request.redirect("/my")
        try:
            contract.sudo().portal_approve(
                ip_address=request.httprequest.remote_addr,
                partner=request.env.user.partner_id,
            )
        except UserError:
            pass
        return request.redirect("/my/contracts/%s" % contract_id)

    @http.route(["/my/contracts/<int:contract_id>/download"], type="http",
                auth="user", website=True)
    def portal_contract_download(self, contract_id, **kw):
        try:
            contract = self._get_contract(contract_id)
        except (AccessError, MissingError):
            return request.redirect("/my")
        pdf, _dummy = request.env["ir.actions.report"].sudo()._render_qweb_pdf(
            "levante_contract.action_report_contract", [contract.id])
        headers = [
            ("Content-Type", "application/pdf"),
            ("Content-Length", len(pdf)),
            ("Content-Disposition",
             'attachment; filename="Levante_Agreement_%s.pdf"'
             % contract.name.replace("/", "_")),
        ]
        return request.make_response(pdf, headers=headers)
