# -*- coding: utf-8 -*-
from odoo import fields, models


class ResPartner(models.Model):
    _inherit = "res.partner"

    levante_partner_type = fields.Selection([
        ("gallery", "Gallery"),
        ("artist", "Artist"),
        ("curator", "Curator"),
        ("service", "Service Provider"),
    ], string="Levante Partner Type")
    levante_contract_ids = fields.One2many(
        "levante.contract", "partner_id", string="Levante Contracts")
    levante_contract_count = fields.Integer(
        compute="_compute_levante_contract_count")

    def _compute_levante_contract_count(self):
        data = self.env["levante.contract"]._read_group(
            [("partner_id", "in", self.ids)], ["partner_id"], ["__count"])
        counts = {p.id: c for p, c in data}
        for rec in self:
            rec.levante_contract_count = counts.get(rec.id, 0)

    def action_view_levante_contracts(self):
        self.ensure_one()
        return {
            "type": "ir.actions.act_window",
            "name": "Contracts",
            "res_model": "levante.contract",
            "view_mode": "list,form",
            "domain": [("partner_id", "=", self.id)],
            "context": {"default_partner_id": self.id},
        }
