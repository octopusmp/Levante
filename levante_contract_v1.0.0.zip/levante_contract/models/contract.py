# -*- coding: utf-8 -*-
from odoo import api, fields, models, _
from odoo.exceptions import UserError


class LevanteContract(models.Model):
    _name = "levante.contract"
    _description = "Levante Supplier Contract"
    _inherit = ["mail.thread", "mail.activity.mixin"]
    _order = "id desc"

    name = fields.Char(
        string="Contract Reference", required=True, copy=False,
        readonly=True, default=lambda self: _("New"))
    company_id = fields.Many2one(
        "res.company", string="Levante Company", required=True,
        default=lambda self: self.env.company)
    partner_id = fields.Many2one(
        "res.partner", string="Counterparty", required=True, tracking=True,
        help="Gallery, artist or curator this contract is signed with.")
    contract_type = fields.Selection([
        ("gallery", "Gallery"),
        ("artist", "Artist"),
        ("curator", "Curator"),
    ], string="Contract Type", required=True, default="gallery", tracking=True)
    holding_type = fields.Selection([
        ("consignment", "Consignment"),
        ("purchase", "Outright Purchase"),
    ], string="Holding Type", required=True, default="consignment")
    commission_percent = fields.Float(
        string="Levante Commission (%)", default=40.0, tracking=True)
    reconciliation_period = fields.Selection([
        ("monthly", "Monthly"),
        ("biweekly", "Every 15 Days"),
        ("instant", "Per Sale"),
    ], string="Reconciliation Period", required=True, default="monthly")
    covered_artist_ids = fields.Many2many(
        "res.partner", "levante_contract_artist_rel", "contract_id", "partner_id",
        string="Covered Artists",
        help="Artists represented under this contract (gallery contracts).")
    # Curator block (Model A default)
    curator_id = fields.Many2one("res.partner", string="Curator")
    curator_fee_type = fields.Selection([
        ("percent_sale", "% of Sale Price"),
        ("fixed_artwork", "Fixed per Artwork"),
        ("fixed_collection", "Fixed per Collection"),
    ], string="Curator Fee Type", default="percent_sale")
    curator_fee_value = fields.Float(string="Curator Fee Value")
    curator_fee_source = fields.Selection([
        ("model_a", "Model A - From Levante Commission"),
        ("model_b", "Model B - From Supplier Share"),
        ("model_c", "Model C - Added on Top of Price"),
    ], string="Curator Fee Source", default="model_a")

    payment_method_note = fields.Char(
        string="Supplier Payment Method",
        help="e.g. Bank transfer to IBAN, within X days of reconciliation invoice.")
    date_start = fields.Date(string="Start Date", default=fields.Date.context_today)
    date_end = fields.Date(string="End Date")

    state = fields.Selection([
        ("draft", "Draft"),
        ("sent", "Sent to Portal"),
        ("approved", "Approved"),
        ("cancelled", "Cancelled"),
    ], string="Status", default="draft", tracking=True, copy=False)

    approved_date = fields.Datetime(string="Approved On", readonly=True, copy=False)
    approved_ip = fields.Char(string="Approval IP", readonly=True, copy=False)
    approved_by_partner_id = fields.Many2one(
        "res.partner", string="Approved By", readonly=True, copy=False)

    @api.model_create_multi
    def create(self, vals_list):
        for vals in vals_list:
            if vals.get("name", _("New")) == _("New"):
                vals["name"] = self.env["ir.sequence"].next_by_code(
                    "levante.contract") or _("New")
        records = super().create(vals_list)
        return records

    # ------- Buttons -------
    def action_send_portal(self):
        for rec in self:
            if not rec.partner_id.email:
                raise UserError(_(
                    "Counterparty has no e-mail address. "
                    "Set it on the contact before sending."))
            rec.state = "sent"
            rec.message_subscribe(partner_ids=rec.partner_id.ids)
            base_url = rec.get_base_url()
            link = "%s/my/contracts/%s" % (base_url, rec.id)
            body = _(
                "Dear %(partner)s,<br/><br/>"
                "Your agreement <b>%(ref)s</b> with Levante Contemporary is ready "
                "for your review and approval.<br/>"
                "Please sign in to your portal account and open: "
                "<a href='%(link)s'>%(link)s</a><br/><br/>"
                "Levante Contemporary",
                partner=rec.partner_id.name, ref=rec.name, link=link)
            rec.message_post(
                body=body,
                partner_ids=rec.partner_id.ids,
                subject=_("Your Levante agreement %s", rec.name),
                subtype_xmlid="mail.mt_comment",
            )
        return True

    def action_cancel(self):
        self.write({"state": "cancelled"})

    def action_reset_draft(self):
        for rec in self:
            if rec.state == "approved":
                raise UserError(_(
                    "An approved contract cannot be reset. "
                    "Cancel it and create a new version instead."))
        self.write({"state": "draft"})

    def portal_approve(self, ip_address, partner):
        """Called from the portal controller."""
        self.ensure_one()
        if self.state != "sent":
            raise UserError(_("This contract is not awaiting approval."))
        self.write({
            "state": "approved",
            "approved_date": fields.Datetime.now(),
            "approved_ip": ip_address or "",
            "approved_by_partner_id": partner.id,
        })
        self.message_post(body=_(
            "Contract approved via portal by %(partner)s "
            "on %(dt)s from IP %(ip)s.",
            partner=partner.display_name,
            dt=fields.Datetime.now(),
            ip=ip_address or "-"))
        return True
